
Partial Class Sponsors
    Inherits System.Web.UI.Page

End Class
