
Partial Class PageOne
    Inherits System.Web.UI.Page

End Class
