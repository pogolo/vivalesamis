
Partial Class ThankYou
    Inherits System.Web.UI.Page

End Class
