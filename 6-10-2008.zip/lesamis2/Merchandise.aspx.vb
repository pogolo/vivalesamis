
Partial Class Merchandise
    Inherits System.Web.UI.Page

End Class
