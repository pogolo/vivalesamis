
Partial Class History
    Inherits System.Web.UI.Page

End Class
