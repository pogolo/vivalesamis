
Partial Class Synopsis
    Inherits System.Web.UI.Page

End Class
