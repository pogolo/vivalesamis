
Partial Class Press
    Inherits System.Web.UI.Page

End Class
